import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import Assert from "../../helper/wrapper/assert";
import HomePage from "../../pages/homepage";
import BrowseAll from "../../pages/browseall";

let homepage: HomePage;
let browseall: BrowseAll;
let assert: Assert;

setDefaultTimeout(60 * 1000 * 2)

Given('user is on any page of the Quartex Published Site', async function () {
  homepage = new HomePage(fixture.page);
  assert = new Assert(fixture.page);
  //await fixture.page.goto(process.env.BASEURL);
  await homepage.navigateToHomePage();
    fixture.logger.info("Navigated to the application")
  });

  When('user enters {string} in the basic search input box', async function (searchTerm) {
     await homepage.enterSearchTerm(searchTerm);
  });

  Then('the page displays {string} with {string}', async function (searchResultNo, titleString) {
    await fixture.page.waitForTimeout(3000);
    await browseall.verifyTextShowing(searchResultNo,titleString);
    });
    
  Then('the search button is clicked', async function () {
  await homepage.clickSearchButton();
  });

  Then('user is navigated to the Browse All page', async function () {
    browseall = new BrowseAll(fixture.page);
    await browseall.verifyBrowseAllPage();
    console.log("User successfully navigated to the Browse All page.");
  });

  Then('the first page of search results is displayed', async function () {
          await fixture.page.waitForTimeout(2000);
          fixture.logger.info("Waiting for 2 seconds")
    await browseall.verifySearchPagination();
     const text = await fixture.page.locator(browseall.Elements.searchFirstPage).textContent();
     console.log("searchTerm: " + text);
     await assert.assertTextContains(browseall.Elements.searchFirstPage,text);
    });

  Then('the assets listed meet the search criteria', async function () {
    await fixture.page.waitForTimeout(3000);
    await browseall.verifySearchCriteria();
    const searchResultTitleSelector = '.result-title';
    const searchResults = await fixture.page.$$(searchResultTitleSelector);
      for (const result of searchResults) {
        const title = await result.innerText();
        expect(title.toLowerCase()).toContain(this.searchTerm.toLowerCase());
    }
    });

    /* Scenario 2 */
      Given('user has performed a successful basic search for {string}', async function (searchTerm) {
        browseall = new BrowseAll(fixture.page);
        await homepage.enterSearchTerm(searchTerm);
        await homepage.clickSearchButton();
        await fixture.page.waitForTimeout(2000);
      });

      When('user selects to filter the search results by {string}', async function (CollectionFilter) {
            //await fixture.page.waitForTimeout(2000);
              await browseall.checkboxFilter(CollectionFilter);
              await browseall.clickApply();
      });

      /* Scenario 3 */
When('there are no assets meeting the search criteria', async function () {
  await browseall.verifyTextShowingZero();
});

Then('a {string} is output informing the user that no results are available', async function (NoMatch) {
  await browseall.verifyNoResultsFound();
  console.log("Sorry, no results found that match your criteria.");
});