import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import Assert from "../../helper/wrapper/assert";
import HomePage from "../../pages/homepage";
import BrowseAll from "../../pages/browseall";
import TheBrownings from "../../pages/brownings";
import BrowseByCollection from "../../pages/browsebycoll";

//let homepage: HomePage;
//let browseall: BrowseAll;
//let brownings: TheBrownings;
let browsebycoll: BrowseByCollection;
//let assert: Assert;

setDefaultTimeout(60 * 1000 * 2)

Given('user is viewing the Browse by collection Name A-Z content block', async function () {
browsebycoll = new BrowseByCollection(fixture.page);
await browsebycoll.navigateToBrowseByCollectionsPage();
await fixture.page.waitForTimeout(2000);
});
When('user selects {string} to browse', async function (Alphabets) {
await browsebycoll.clickLetterW(Alphabets);
await fixture.page.waitForTimeout(2000);
});
Then('the page is scrolled to display all {string} starting with the chosen letter', async function (Link) {
await browsebycoll.verifyTextWar(Link);
await fixture.page.waitForTimeout(2000);
});

  Given('user has chosen to view all collections starting with a chosen {string}', async function (Alphabets) {
    await browsebycoll.clickLetterW(Alphabets);
    await fixture.page.waitForTimeout(2000);
  });

  When('user clicks on the {string}', async function (Link) {
    await browsebycoll.clickWarConflictLink(Link);
    await fixture.page.waitForTimeout(4000);
  });

  Then('user is navigated to the results page with the header equal to chosen collection title AND {string} within the collection are listed', async function (searchResultNo2) {
    await browsebycoll.verifyTitleWar();
    await browsebycoll.verifyTextShowing2(searchResultNo2);
  });

  Then('the {string} is visible', async function (titleString2: string) {
    await browsebycoll.verifyTitleTextElements2(titleString2);
  });
