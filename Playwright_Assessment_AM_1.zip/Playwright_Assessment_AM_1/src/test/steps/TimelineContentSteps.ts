import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import Assert from "../../helper/wrapper/assert";
import HomePage from "../../pages/homepage";
import BrowseAll from "../../pages/browseall";
import TheBrownings from "../../pages/brownings";

//let homepage: HomePage;
//let browseall: BrowseAll;
let brownings: TheBrownings;
//let assert: Assert;

setDefaultTimeout(60 * 1000 * 2)

Then('user has navigated to a Timeline content block', async function () {
    brownings = new TheBrownings(fixture.page);
     await brownings.DiscoverAidsLink();
     await brownings.TCBlockLink();
});
When('user clicks a hyperlink available on the {string}', async function (Timelineitem) {
       await brownings.LoveLetterLink();
});
Then('the correct webpage is launched in a new tab for {string}', async function (Timelineitem) {
        const [newPage] = await Promise.all([
        this.page.context().waitForEvent('page'), // captures the new tab
        this.page.click(brownings.Elements.LoveLetterElement(Timelineitem)) // triggers the new tab
    ]);
    await newPage.waitForLoadState('load');
    
    // Log the URL of the new tab
    const actualURL = newPage.url();
    console.log("The Actual URL of the new tab is: ", actualURL);
    const expectedURL = "https://demo.quartexcollections.com/Documents/Detail/10-january-1845.-browning-robert-to-browning-elizabeth-barrett./36113"; 
    expect(actualURL).toBe(expectedURL);
    
    await newPage.close();

});