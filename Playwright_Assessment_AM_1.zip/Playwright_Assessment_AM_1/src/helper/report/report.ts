const report = require("multiple-cucumber-html-reporter");

report.generate({
    jsonDir: "test-results",
    reportPath: "test-results/reports/",
    reportName: "Playwright Automation Report",
    pageTitle: "AM demo Appln test report",
    displayDuration: false,
    metadata: {
        browser: {
            name: "chrome",
            version: "114",
        },
        device: "Udhay - MacBook Pro",
        platform: {
            name: "macOS",
            version: "13.4",
        },
    },
    customData: {
        title: "Test Info",
        data: [
            { label: "Project", value: "AM demo appln" },
            { label: "Release", value: "1.2.3" },
            { label: "Cycle", value: "RegressionPack-01-Jira01" }
        ],
    },
});