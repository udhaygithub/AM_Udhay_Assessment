export { };

declare global {
    namespace NodeJS {
        interface ProcessEnv {
            BROWSER: "chrome" | "firefox" | "webkit",
            ENV: "sit" | "preprod" | "prod",
            BASEURL: string,
            HEAD: "true" | "false"
        }
    }
}