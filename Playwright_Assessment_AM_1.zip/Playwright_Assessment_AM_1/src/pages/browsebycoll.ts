import { expect, Page } from "@playwright/test";
import PlaywrightWrapper from "../helper/wrapper/PlaywrightWrappers";
import { fixture } from "../hooks/pageFixture";

export default class BrowseByCollection {
    private base: PlaywrightWrapper
    constructor(private page: Page) {
        this.base = new PlaywrightWrapper(page);
    }
    public Elements = {
        PaginationArrowClick: "//span[@class='points points--right']//*[name()='svg']",
        //clickW: "//span[contains(text(), 'W')]",
        clickW: (SelectAlphabet: string) => `//span[contains(text(), '${SelectAlphabet}')]`,
        //LinkWar: "//h4[contains(text(), 'War & Conflict')]",   
        LinkWar: (SelectLink: string) => `//h4[contains(text(), '${SelectLink}')]`,   
        TitleWar: "//h1[@class='heading heading--tertiary mark-highlightable']",
        textShowing2: "(//div[@class='media-list__top-pagination-info bold'])[1]",
        titleTextElements2:"//h3/following::a[contains(text(), 'Memoirs of a Prisoner of War')]",
      }
      
      async navigateToBrowseByCollectionsPage() {
      await this.page.goto("https://demo.quartexcollections.com/explore-the-collections")
      }
  
      async clickPaginationArrow() {
        await this.page.click(this.Elements.PaginationArrowClick);
        }      
        async clickLetterW(Alphabets) {
        await this.page.click(this.Elements.clickW(Alphabets));
        }
      async verifyTextWar(Link) {
      await expect(this.page.locator(this.Elements.LinkWar(Link)))
      .toBeVisible();
      }
      async clickTextWar(Alphabets) {
      await this.page.click(this.Elements.clickW(Alphabets));
      }
      async verifyTitleWar() {
      await expect(this.page.locator(this.Elements.TitleWar))
      .toBeVisible();
      }
      async clickWarConflictLink(Link) {
      await this.page.click(this.Elements.LinkWar(Link));
      }
async verifyTextShowing2(textShowing22: number): Promise<void> {
        // Locate the element and extract its text content
        const text = await this.page.locator(this.Elements.textShowing2).textContent();
        console.log("textshowing Locator is:", text);
        // Used regex to extract the number after "of"
        const match = text?.match(/of (\d+)/);

        if (match && match[1]) {
          const extractedNumber = parseInt(match[1], 10); // Convert the matched string to an int
          console.log("Extracted number:", extractedNumber);
          fixture.logger.info("Extracted number:", extractedNumber)
        
  // Assert that the extracted number matches the expected value   
          await expect(extractedNumber.toString()).toBe(textShowing22.toString());
        } else {
          console.error("Number not found in text:", text);
          fixture.logger.error("Number not found in text:", text)
        }
      }
  async verifyTitleTextElements2(titleString2: string): Promise<void> {
  const searchResults = await fixture.page.$$(this.Elements.titleTextElements2);
// Variable to track if any title matches the expected string
          
   let isMatchFound = false;

// Iterate search results through the list
   for (const result of searchResults) {
   const title = await result.textContent();

    if (title) {
      if (title.includes(titleString2)) {
        isMatchFound = true;
        console.log(`Match found for title: "${title}"`);
        fixture.logger.info(`Match found for title: "${title}"`);
      }
    } else {
      console.error("Element text is undefined or null");
      fixture.logger.error("Element text is undefined or null");
    }
  }
  // Fail the test if no match was found
  if (!isMatchFound) {
    throw new Error(
      `Expected title "${titleString2}" not found in any of the retrieved results.`
    );
  } 
}
}