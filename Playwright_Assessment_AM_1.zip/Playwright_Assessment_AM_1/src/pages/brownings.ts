import { expect, Page } from "@playwright/test";
import PlaywrightWrapper from "../helper/wrapper/PlaywrightWrappers";
import { fixture } from "../hooks/pageFixture";

export default class TheBrownings {
    private base: PlaywrightWrapper
    constructor(private page: Page) {
    this.base = new PlaywrightWrapper(page);
    }

    public Elements = {
        clickDiscoverAids: "//a[contains(@role,'button')][normalize-space()='Discovery Aids']",
        clickTCBlock: "//a[contains(text(),'The Brownings: A Brief History')]",
        TheBrowningstext: "//h2[@class='heading heading--secondary mark-highlightable']",
      //LoveLetterElement: "//h3[contains(text(), '1845')]/following::a[1]",
        LoveLetterElement: (timelineitem: string) => `//h3[contains(text(), '${timelineitem}')]/following::a[1]`,
        JanuaryText: "//h1[@class='heading heading--tertiary document-viewer__heading']",
      }
      async DiscoverAidsLink() {
      await this.page.click(this.Elements.clickDiscoverAids);
      }
      async TCBlockLink() {
      await this.page.click(this.Elements.clickTCBlock);
      }
      async navigateToBrowningPage() {
      await this.page.goto("https://demo.quartexcollections.com/discovery-aids/the-brownings-a-brief-history")
      }
      async verifyTheBrowningsText() {
      await expect(this.page.locator(this.Elements.TheBrowningstext))
      .toBeVisible();
      }     
    //   async LoveLetterLink() {
    //   await this.page.click(this.Elements.LoveLetterClick);
    //   }
async LoveLetterLinkOld() {
    await this.page.waitForTimeout(20000);
    await fixture.page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await this.page.waitForTimeout(3000);
    await this.page.click(this.Elements.LoveLetterElement("1845"));
    await this.page.waitForTimeout(3000);
    console.log("Scroll worked and Clicked!!");
  }
  async LoveLetterLink() {
    await this.page.waitForTimeout(20000);
    await fixture.page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await this.page.waitForTimeout(3000);
}
  async verifyJanuaryText() {
    await expect(this.page.locator(this.Elements.JanuaryText))
    .toBeVisible();
    }
  }