import { expect, Page } from "@playwright/test";
import PlaywrightWrapper from "../helper/wrapper/PlaywrightWrappers";
import { fixture } from "../hooks/pageFixture";

export default class BrowseAll {
    private base: PlaywrightWrapper
    constructor(private page: Page) {
    this.base = new PlaywrightWrapper(page);
    }
    public Elements = {
        BrowseAlltext: "//h1[@class='heading heading--tertiary mark-highlightable']",
        searchFirstPage: "(//input[@class='form-field media-list__top-pagination-options__input' and @id='pagination-top-page'])",
        searchFirstCriteria: "//a[contains(text(),'[10 January 1845]. Browning, Robert to Browning, E')]",
        textShowing: "(//div[@class='media-list__top-pagination-info bold'])[1]",
        selectFilter: "//label[@for='chk-box-interwar-periodicals']",
        clickApply: "//body/div[@id='main-content']/div[@id='documents-list-view']/div[@class='view']/section[@class='view__main view__main--grey']/div[@class='view__main__inner']/div[@class='wrapper wrapper--flush']/div[@class='media-list is-bound']/aside[@id='filters']/div/section[@data-bind='visible: showingStaticContentResults() === false']/div[1]/button[1]/span[1]",
        noResultsFound: "//span[normalize-space()='Sorry, no results found that match your criteria.']",
        textShowingZero: "//div[@id='docs-list-panel']//div[@class='media-list__inner']//div[2]",
        titleTextElements:"//a[@class='media-object__heading__link bold breakword-for-long-text']",
      }

      async navigateToBrowsePage() {
      await this.base.goto("https://demo.quartexcollections.com/documents?returning=true")
      }
      async verifyBrowseAllPage() {
      await expect(this.page.locator(this.Elements.BrowseAlltext))
      .toBeVisible();
      }
      async verifySearchPagination() {
      await expect(this.page.locator(this.Elements.searchFirstPage))
      .toBeVisible();
      }
      async verifyTextShowing(textShowing: number, titleString: string): Promise<void> {
            // Locate the element & extract its text content
            const text = await this.page.locator(this.Elements.textShowing).textContent();

            // Used regex to extract the number after "of"
            const match = text?.match(/of (\d+)/); // Use a regex to find "of <number>"

            if (match && match[1]) {
              const extractedNumber = parseInt(match[1], 10); // Convert the matched string to int
              console.log("Extracted number:", extractedNumber);
              fixture.logger.info("Extracted number:", extractedNumber)

              // Assert that the extracted number matches the expected value           
              await expect(extractedNumber.toString()).toBe(textShowing.toString());
            } else {
              console.error("Number not found in text:", text);
              fixture.logger.error("Number not found in text:", text)
            }

            // Steps to verify the title string
            const searchResults = await fixture.page.$$(this.Elements.titleTextElements);
           // Variable to track if any title matches the expected string
          
  let isMatchFound = false;

  // Iterate through all search results
  for (const result of searchResults) {
    const title = await result.textContent();
    if (title) {
      if (title.includes(titleString)) {
        isMatchFound = true;
        console.log(`Match found for title: "${title}"`);
        fixture.logger.info(`Match found for title: "${title}"`);
      }
    } else {
      console.error("Element text is undefined or null");
      fixture.logger.error("Element text is undefined or null");
    }
  }
  // Fail the test if no match was found
  if (!isMatchFound) {
    throw new Error(
      `Expected title "${titleString}" not found in any of the retrieved results.`
    );
  }
    }
      async verifySearchCriteria() {
      await expect(this.page.locator(this.Elements.searchFirstCriteria))
      .toBeVisible();        
      }
      async verifyTextShowingZero() {
      await expect(this.page.locator(this.Elements.textShowingZero))
      .toBeVisible();        
      }      
      async checkboxFilter(searchTerm: any) {
      await this.page.click(this.Elements.selectFilter);
      }
      async clickApply() {
      await this.page.click(this.Elements.clickApply);
      }
      async verifyNoResultsFound() {
      await expect(this.page.locator(this.Elements.noResultsFound))
      .toBeVisible();
      }
}