import { expect, Page } from "@playwright/test";
import PlaywrightWrapper from "../helper/wrapper/PlaywrightWrappers";
//import HomePage from "../../pages/homepage";
//import Assert from "../../helper/wrapper/assert";
//let homepage: HomePage;
//let assert: Assert;

export default class HomePage {
    private base: PlaywrightWrapper
    constructor(private page: Page) {
    this.base = new PlaywrightWrapper(page);
    }

    private Elements = {
    searchTerm: "#search_input_intro",
    searchButton: "//button[@aria-label='Search the site']//*[name()='svg']",
    }

    async navigateToHomePage() {
    await this.base.goto("https://demo.quartexcollections.com/")
    }

    async enterSearchTerm(searchTerm: string) {
    await this.page.type(this.Elements.searchTerm, searchTerm);
    console.log('Entered search term:', searchTerm);
    }
    
    async clickSearchButton() {
    const searchBttn = this.page.locator(this.Elements.searchButton);
    await searchBttn.click();
    console.log('Clicked the search button');
    }
}